// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("conformance suite"); }
int main(){
  announce();
  return lionss_run_workload("conformance-suite");
}
