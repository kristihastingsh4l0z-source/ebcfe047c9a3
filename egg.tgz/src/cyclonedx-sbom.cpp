// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cyclonedx sbom\n", stdout);
  return lionss_run_workload("cyclonedx-sbom");
}
