// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("android arm64"); }
int main(){
  announce();
  return lionss_run_workload("android-arm64");
}
