// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("strict warnings"); }
int main(){
  announce();
  return lionss_run_workload("strict-warnings");
}
